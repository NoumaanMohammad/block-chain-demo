import java.util.*;


public class BlockChain
{

	public static ArrayList<Block> blockChain = new ArrayList<Block>();

	public static void main(String args[])
	{
		Block first = new Block("Heyy I am First","0");
		System.out.print("\nHash for blcok 1 : "+first.hash);

		Block second = new Block("Heyy I am Second",first.hash);
		System.out.print("\nHash for blcok 2 : "+second.hash);

		
		Block third = new Block("Heyy I am third",second.hash);
		System.out.print("\nHash for blcok 3 : "+third.hash);

		Block fourth = new Block("Heyy I am fourth",third.hash);
		System.out.print("\nHash for blcok 4 : "+fourth.hash);


		blockChain.add(first);
		blockChain.add(second);
		blockChain.add(third);
		blockChain.add(fourth);

		second.data = "Hii i am forth";
		second.hash = second.calculateHash();
		third.prevHash = second.hash;
		third.hash = third.calculateHash();		

		System.out.print("\nIs chain valid : "+isChainValid());

	}

	public static boolean isChainValid()
	{
		Block current;
		Block prev;
		
		for(int i=1;i<blockChain.size();i++)
		{
			current = blockChain.get(i);
			prev = blockChain.get(i-1);
			
			if(!current.hash.equals(current.calculateHash()))
			{		
				System.out.print("\nCurrent Block Hashes dont match");
				return false;
			}
			if(!current.prevHash.equals(prev.calculateHash()))
			{		
				System.out.print("\nPrevious Block Hashes dont match");
				return false;
			}

		}
		
		return true;

	}

}